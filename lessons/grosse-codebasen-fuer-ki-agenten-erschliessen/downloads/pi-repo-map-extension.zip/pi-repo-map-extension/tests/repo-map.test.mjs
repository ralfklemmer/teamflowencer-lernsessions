import assert from "node:assert/strict";
import test from "node:test";

import {
  DEFAULT_MAP_TOKENS,
  buildAiderArguments,
  formatAiderFailure,
  resolveRepositoryPath,
  runAiderRepoMap,
} from "../repo-map.ts";

test("builds the validated non-interactive Aider repo-map invocation", () => {
  assert.deepEqual(buildAiderArguments(DEFAULT_MAP_TOKENS), [
    "--no-gitignore",
    "--model",
    "gpt-4o-mini",
    "--no-show-model-warnings",
    "--show-repo-map",
    "--map-tokens",
    "2048",
  ]);
});

test("passes a custom map token budget to Aider", () => {
  assert.equal(buildAiderArguments(4096).at(-1), "4096");
});

test("resolves omitted, relative, absolute, and Pi @-prefixed repository paths", () => {
  const cwd = "/workspace/project";

  assert.equal(resolveRepositoryPath(cwd), cwd);
  assert.equal(resolveRepositoryPath(cwd, "services/api"), "/workspace/project/services/api");
  assert.equal(resolveRepositoryPath(cwd, "/tmp/repository"), "/tmp/repository");
  assert.equal(resolveRepositoryPath(cwd, "@services/api"), "/workspace/project/services/api");
});

test("formats an actionable Aider failure without hiding stderr", () => {
  assert.equal(
    formatAiderFailure({ code: 2, stderr: "fatal: not a git repository", stdout: "" }),
    "Aider repo map failed with exit code 2: fatal: not a git repository",
  );
});

test("falls back to stdout and then a generic diagnostic for Aider failures", () => {
  assert.match(
    formatAiderFailure({ code: 1, stderr: "", stdout: "usage error" }),
    /usage error/,
  );
  assert.match(
    formatAiderFailure({ code: 1, stderr: "", stdout: "" }),
    /no diagnostic output/i,
  );
});

test("runs Aider in the resolved repository with timeout and cancellation", async () => {
  const calls = [];
  const signal = new AbortController().signal;
  const execute = async (command, args, options) => {
    calls.push({ command, args, options });
    if (command === "git") {
      return { code: 0, killed: false, stdout: "/workspace/project\n", stderr: "" };
    }
    return { code: 0, killed: false, stdout: "src/main.ts:\n│export function main()", stderr: "" };
  };

  const result = await runAiderRepoMap({
    cwd: "/workspace",
    path: "@project",
    mapTokens: 4096,
    signal,
    execute,
  });

  assert.equal(result.output, "src/main.ts:\n│export function main()");
  assert.equal(result.repositoryPath, "/workspace/project");
  assert.equal(result.mapTokens, 4096);
  assert.equal(calls.length, 2);
  assert.equal(calls[0].command, "git");
  assert.deepEqual(calls[0].args, ["rev-parse", "--show-toplevel"]);
  assert.deepEqual(calls[0].options, {
    cwd: "/workspace/project",
    signal,
    timeout: 10_000,
  });
  assert.equal(calls[1].command, "aider");
  assert.deepEqual(calls[1].args, buildAiderArguments(4096));
  assert.deepEqual(calls[1].options, {
    cwd: "/workspace/project",
    signal,
    timeout: 120_000,
  });
});

test("rejects a non-Git directory before starting Aider", async () => {
  const calls = [];
  await assert.rejects(
    runAiderRepoMap({
      cwd: "/workspace/not-a-repository",
      execute: async (command) => {
        calls.push(command);
        return {
          code: 128,
          killed: false,
          stdout: "",
          stderr: "fatal: not a git repository",
        };
      },
    }),
    /Not a Git repository: \/workspace\/not-a-repository/,
  );
  assert.deepEqual(calls, ["git"]);
});

test("throws an actionable error when Aider exits unsuccessfully", async () => {
  await assert.rejects(
    runAiderRepoMap({
      cwd: "/workspace",
      execute: async (command) => command === "git"
        ? { code: 0, killed: false, stdout: "/workspace\n", stderr: "" }
        : { code: 2, killed: false, stdout: "", stderr: "Aider failed" },
    }),
    /exit code 2: Aider failed/,
  );
});

test("identifies a missing Aider executable", async () => {
  await assert.rejects(
    runAiderRepoMap({
      cwd: "/workspace",
      execute: async (command) => {
        if (command === "git") {
          return { code: 0, killed: false, stdout: "/workspace\n", stderr: "" };
        }
        throw new Error("spawn aider ENOENT");
      },
    }),
    /Unable to start aider: spawn aider ENOENT/,
  );
});
