#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEST_ROOT="$(mktemp -d /tmp/pi-repo-map-installer-test.XXXXXX)"
FAKE_BIN="$TEST_ROOT/bin"
LOG_FILE="$TEST_ROOT/pi.log"
mkdir -p "$FAKE_BIN"

cleanup() {
  if command -v trash >/dev/null 2>&1; then
    trash "$TEST_ROOT"
  else
    TEST_ROOT="$TEST_ROOT" node -e 'require("node:fs").rmSync(process.env.TEST_ROOT, { recursive: true, force: true })'
  fi
}
trap cleanup EXIT

write_fake_pi() {
  cat > "$FAKE_BIN/pi" <<'SCRIPT'
#!/usr/bin/env bash
printf '%s\n' "$@" > "$PI_TEST_LOG"
SCRIPT
  chmod +x "$FAKE_BIN/pi"
}

write_fake_git() {
  cat > "$FAKE_BIN/git" <<'SCRIPT'
#!/usr/bin/env bash
exit 0
SCRIPT
  chmod +x "$FAKE_BIN/git"
}

write_fake_aider() {
  local help_text="$1"
  cat > "$FAKE_BIN/aider" <<SCRIPT
#!/usr/bin/env bash
if [ "\${1:-}" = "--help" ]; then
  printf '%s\n' '$help_text'
  exit 0
fi
if [ "\${1:-}" = "--version" ]; then
  printf '%s\n' 'aider 0.86.2'
  exit 0
fi
exit 0
SCRIPT
  chmod +x "$FAKE_BIN/aider"
}

write_fake_pi
write_fake_git
write_fake_aider '  --show-repo-map  Print the repo map and exit'

PI_TEST_LOG="$LOG_FILE" PATH="$FAKE_BIN:/usr/bin:/bin" "$PACKAGE_DIR/install.sh" > "$TEST_ROOT/success.out"
{
  IFS= read -r first_pi_arg
  IFS= read -r second_pi_arg
} < "$LOG_FILE"
[ "$first_pi_arg" = "install" ]
[ "$second_pi_arg" = "$PACKAGE_DIR" ]
grep -Fq 'Installed pi-repo-map-extension' "$TEST_ROOT/success.out"

mv "$FAKE_BIN/aider" "$FAKE_BIN/aider.disabled"
if PI_TEST_LOG="$LOG_FILE" PATH="$FAKE_BIN:/usr/bin:/bin" "$PACKAGE_DIR/install.sh" > "$TEST_ROOT/missing.out" 2>&1; then
  echo 'FAIL: installer accepted a missing aider executable' >&2
  exit 1
fi
grep -Fq 'Missing dependency: aider' "$TEST_ROOT/missing.out"

write_fake_aider 'usage: aider'
if PI_TEST_LOG="$LOG_FILE" PATH="$FAKE_BIN:/usr/bin:/bin" "$PACKAGE_DIR/install.sh" > "$TEST_ROOT/flag.out" 2>&1; then
  echo 'FAIL: installer accepted aider without --show-repo-map' >&2
  exit 1
fi
grep -Fq 'does not support --show-repo-map' "$TEST_ROOT/flag.out"

echo 'PASS: standalone installer validates dependencies and installs only this package'
