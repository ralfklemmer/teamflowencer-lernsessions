#!/usr/bin/env bash
set -euo pipefail

EXTENSION_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT="$({ printf '%s\n' '{"id":"registration","type":"get_state"}'; } | pi \
  --mode rpc \
  --no-session \
  --no-extensions \
  --no-builtin-tools \
  --extension "$EXTENSION_DIR/index.ts")"

grep -Fq '"id":"registration"' <<<"$OUTPUT"
grep -Fq '"command":"get_state"' <<<"$OUTPUT"
grep -Fq '"success":true' <<<"$OUTPUT"

if grep -Fq '"type":"extension_error"' <<<"$OUTPUT"; then
  echo "FAIL: extension_error emitted" >&2
  exit 1
fi

echo "PASS: repo-map extension loads in isolated Pi RPC mode"
