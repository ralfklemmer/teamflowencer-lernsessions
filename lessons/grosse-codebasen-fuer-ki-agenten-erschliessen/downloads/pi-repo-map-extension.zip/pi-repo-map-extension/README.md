# Pi Repo Map Extension

Eigenständige Pi-Extension für eine kompakte, globale Übersicht wichtiger Dateien und Symbole eines Git-Repositories. Das Tool kapselt den bereits validierten Aider-CLI-Aufruf `aider --show-repo-map`.

```text
Pi + LLM
   ↓
repo_map
   ↓
git rev-parse --show-toplevel
   ↓
aider --show-repo-map
   ↓
Aider Tree-Sitter-/Tags-Cache
   ↓
begrenzter Tool-Output für Pi
```

## Eigenschaften

- keine Codeänderungen
- keine LLM-Anfrage durch Aider
- globale, prompt-unabhängige Repository-Orientierung
- Aiders nativer Tree-Sitter-/Tags-Cache
- Schutz vor Aiders interaktivem Non-Git-Fehlerpfad
- maximal 2.000 Zeilen oder 50 KB im Pi-Kontext
- vollständige Map in einer temporären Datei, falls der Output gekürzt wird

## Abhängigkeiten

| Abhängigkeit | Zweck | Validierter Stand |
|---|---|---|
| Pi Coding Agent (`@earendil-works/pi-coding-agent`) | Extension-Host und Tool-Aufruf | `0.84.2` |
| Git | Repository-Erkennung | aktuelles CLI |
| Aider | Repo-Map-Erzeugung | `0.86.2` |
| Pi-Provider/LLM | Auswahl und Aufruf des Tools im Chat | beliebiger Tool-fähiger Pi-Provider |

Pi stellt die JavaScript-Laufzeitabhängigkeiten `@earendil-works/pi-coding-agent` und `typebox` bereit. Dafür ist kein separates `npm install` erforderlich. Andere Pi-Forks oder ältere Distributionen, die das Modul `@earendil-works/pi-coding-agent` nicht bereitstellen, sind nicht kompatibilitätsgetestet.

Nicht benötigt:

- Serena
- MCP
- Tree-Sitter als separate Installation
- API-Key für Aider
- OpenAI-Zugang durch Aider

Aider verwendet `gpt-4o-mini` ausschließlich als Modell-/Tokenizer-Metadatum. Der `--show-repo-map`-Aufruf sendet keine LLM-Anfrage.

### Aider installieren

Empfohlene, validierte Installation mit `uv`:

```bash
uv python install 3.12
uv tool install --force --python python3.12 --with pip 'aider-chat==0.86.2'

command -v aider
aider --version
```

Erwartet:

```text
aider 0.86.2
```

## Installation

Der entpackte oder geklonte Paketordner muss an einem dauerhaften Ort liegen bleiben. Pi referenziert lokale Pakete, statt sie zu kopieren.

```bash
cd /dauerhafter/pfad/pi-repo-map-extension
chmod +x install.sh
./install.sh
```

Der Installer:

1. prüft `pi`, `git` und `aider` im `PATH`,
2. prüft, ob Aider `--show-repo-map` unterstützt,
3. installiert ausschließlich diesen Paketordner mit `pi install`.

Er installiert keine Systempakete und führt keine fremden Download-Skripte aus.

### Manuelle Installation

```bash
cd /dauerhafter/pfad/pi-repo-map-extension
pi install "$(pwd -P)"
```

### Installation aus einem Git-Repository

Dieser Ordner kann unverändert als Root eines eigenen Git-Repositories veröffentlicht werden:

```bash
git clone <repository-url> pi-repo-map-extension
cd pi-repo-map-extension
./install.sh
```

Direkte Pi-Git-Installation ist ebenfalls möglich, wenn dieser Paketordner das Repository-Root ist. Dabei wird die Dependency-Prüfung des Installers übersprungen:

```bash
pi install git:<repository-url>@<tag-oder-commit>
```

## Verwendung

Pi nach der Installation in einem Git-Repository neu starten:

```bash
cd /pfad/zum/git-repository
pi
```

Beispiel-Prompt:

```text
Erzeuge zuerst mit repo_map eine globale Übersicht dieses Repositories mit 2048 Map-Tokens.
```

Pi ruft dabei das Tool ungefähr so auf:

```json
{
  "map_tokens": 2048
}
```

Für ein anderes Repository:

```json
{
  "path": "/absoluter/pfad/zum/repository",
  "map_tokens": 4096
}
```

## Parameter

### `path`

- optionaler String
- Default: aktuelles Pi-Arbeitsverzeichnis
- absolut oder relativ zum Pi-Arbeitsverzeichnis
- ein führendes Pi-`@` wird entfernt
- Unterverzeichnisse werden auf das Git-Root normalisiert

### `map_tokens`

- optionaler Integer
- Default: `2048`
- Minimum: `256`
- Maximum: `32768`

## Tatsächlicher Aider-Aufruf

Nach einem read-only Git-Preflight:

```bash
git rev-parse --show-toplevel
```

startet das Tool im ermittelten Repository-Root:

```bash
aider \
  --no-gitignore \
  --model gpt-4o-mini \
  --no-show-model-warnings \
  --show-repo-map \
  --map-tokens 2048
```

Timeout: 120 Sekunden. Pi reicht sein AbortSignal an Git und Aider durch.

## Output

Der Text-Output enthält Aiders Repository-Map. Die strukturierten Details enthalten:

```json
{
  "repositoryPath": "/absolutes/git/root",
  "mapTokens": 2048,
  "cachePath": "/absolutes/git/root/.aider.tags.cache.v4",
  "cacheExists": true,
  "fullOutputPath": "/tmp/pi-repo-map-.../repo-map.txt"
}
```

`fullOutputPath` wird nur gesetzt, wenn die Map für den Pi-Kontext gekürzt werden musste.

## Caching und Schreibzugriffe

Die Extension implementiert keinen eigenen Cache. Aider verwaltet seinen nativen Cache:

```text
<git-root>/.aider.tags.cache.v4/cache.db
```

Aider entscheidet selbst über Wiederverwendung und Invalidierung. `cacheExists` zeigt nur die Existenz des Cache-Verzeichnisses an und ist kein Cache-Hit-Indikator.

Die Extension verändert keine getrackten Projektdateien. Aider benötigt jedoch Schreibzugriff für `.aider.tags.cache.v4/`. Dieses Verzeichnis sollte ignoriert werden, beispielsweise lokal über `.git/info/exclude` oder projektweit über `.gitignore`.

## Fehlerfälle

| Fehler | Meldung/Verhalten |
|---|---|
| kein Git-Repository | `Not a Git repository: <path>` |
| Pfad fehlt oder ist nicht zugreifbar | `Unable to inspect repository <path>: <diagnostic>` |
| `aider` fehlt | Installer bricht ab; Runtime meldet `Unable to start aider` |
| Aider unterstützt das Flag nicht | Installer bricht vor der Pi-Installation ab |
| Aider Exit-Code ungleich 0 | Exit-Code plus stderr/stdout werden gemeldet |
| ungültige `map_tokens` | Pi lehnt den Aufruf über das Parameterschema ab |
| Output über 2.000 Zeilen oder 50 KB | gekürzter Kontext-Output plus temporäre vollständige Datei |

## Aktualisierung

Dateien im bestehenden Paketordner ersetzen und danach eine neue Pi-Sitzung starten. In einer laufenden interaktiven Sitzung kann `/reload` verwendet werden.

## Deinstallation

Im unveränderten Paketordner:

```bash
pi remove "$(pwd -P)"
```

Danach kann der Ordner entfernt werden.

## Tests

```bash
npm test
```

Die Tests prüfen:

- exakte Aider-Argumente,
- Pfad- und Git-Root-Auflösung,
- Non-Git-, Aider- und Missing-Executable-Fehler,
- Installer-Dependency-Prüfung,
- isoliertes Laden der Extension in Pi-RPC-Mode.

## Kompatibilität

- validiert auf macOS mit Pi `0.84.2`, Node `26.5.0` und Aider `0.86.2`
- Linux wird erwartet, wurde aber noch nicht nachgewiesen
- Windows wurde nicht validiert
- neuere Pi-/Aider-Versionen können funktionieren, sind aber nicht Bestandteil des aktuellen Validierungsnachweises
