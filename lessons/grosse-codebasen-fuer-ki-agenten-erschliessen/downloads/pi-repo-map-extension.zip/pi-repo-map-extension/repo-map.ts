import { resolve } from "node:path";

export const DEFAULT_MAP_TOKENS = 2048;

interface CommandResult {
  code: number;
  killed: boolean;
  stdout: string;
  stderr: string;
}

interface RunRepoMapOptions {
  cwd: string;
  path?: string;
  mapTokens?: number;
  signal?: AbortSignal;
  execute(
    command: string,
    args: string[],
    options: { cwd: string; signal?: AbortSignal; timeout: number },
  ): Promise<CommandResult>;
}

export function buildAiderArguments(mapTokens: number): string[] {
  return [
    "--no-gitignore",
    "--model",
    "gpt-4o-mini",
    "--no-show-model-warnings",
    "--show-repo-map",
    "--map-tokens",
    String(mapTokens),
  ];
}

export function resolveRepositoryPath(cwd: string, requestedPath?: string): string {
  const normalizedPath = requestedPath?.startsWith("@")
    ? requestedPath.slice(1)
    : requestedPath;

  return resolve(cwd, normalizedPath || ".");
}

export function formatAiderFailure(result: Pick<CommandResult, "code" | "stdout" | "stderr">): string {
  const diagnostic = result.stderr.trim() || result.stdout.trim() || "no diagnostic output";
  return `Aider repo map failed with exit code ${result.code}: ${diagnostic}`;
}

export async function runAiderRepoMap(options: RunRepoMapOptions): Promise<{
  output: string;
  repositoryPath: string;
  mapTokens: number;
}> {
  const requestedRepositoryPath = resolveRepositoryPath(options.cwd, options.path);
  const mapTokens = options.mapTokens ?? DEFAULT_MAP_TOKENS;

  let gitResult: CommandResult;
  try {
    gitResult = await options.execute("git", ["rev-parse", "--show-toplevel"], {
      cwd: requestedRepositoryPath,
      signal: options.signal,
      timeout: 10_000,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Unable to inspect repository ${requestedRepositoryPath}: ${message}`);
  }

  if (gitResult.code !== 0 || !gitResult.stdout.trim()) {
    throw new Error(`Not a Git repository: ${requestedRepositoryPath}`);
  }

  const repositoryPath = gitResult.stdout.trim();
  let result: CommandResult;
  try {
    result = await options.execute("aider", buildAiderArguments(mapTokens), {
      cwd: repositoryPath,
      signal: options.signal,
      timeout: 120_000,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Unable to start aider: ${message}`);
  }

  if (result.code !== 0) {
    throw new Error(formatAiderFailure(result));
  }

  return {
    output: result.stdout.trimEnd(),
    repositoryPath,
    mapTokens,
  };
}
