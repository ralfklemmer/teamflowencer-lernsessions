import { access, mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import {
  DEFAULT_MAX_BYTES,
  DEFAULT_MAX_LINES,
  formatSize,
  truncateHead,
  withFileMutationQueue,
} from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

import { DEFAULT_MAP_TOKENS, runAiderRepoMap } from "./repo-map.js";

interface RepoMapDetails {
  repositoryPath: string;
  mapTokens: number;
  cachePath: string;
  cacheExists: boolean;
  fullOutputPath?: string;
}

async function pathExists(path: string): Promise<boolean> {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

export default function (pi: ExtensionAPI) {
  pi.registerTool({
    name: "repo_map",
    label: "Repo Map",
    description:
      `Generate a read-only global repository map with the validated Aider CLI (` +
      `aider --show-repo-map). No LLM request is made. ` +
      `Aider reuses its native .aider.tags.cache.v4 cache. ` +
      `Output is truncated to ${DEFAULT_MAX_LINES} lines or ${formatSize(DEFAULT_MAX_BYTES)}; ` +
      `the full map is saved to a temporary file if truncated.`,
    promptSnippet: "Generate a compact global map of important repository files and symbols",
    promptGuidelines: [
      "Use repo_map for global codebase orientation before targeted symbol inspection.",
    ],
    parameters: Type.Object({
      path: Type.Optional(Type.String({
        description: "Git repository path, absolute or relative to the Pi working directory (default: current directory)",
      })),
      map_tokens: Type.Optional(Type.Integer({
        minimum: 256,
        maximum: 32768,
        description: `Approximate Aider repo-map token budget (default: ${DEFAULT_MAP_TOKENS})`,
      })),
    }),

    async execute(_toolCallId, params, signal, onUpdate, ctx) {
      onUpdate?.({
        content: [{ type: "text", text: "Generating Aider repository map..." }],
        details: {},
      });

      const result = await runAiderRepoMap({
        cwd: ctx.cwd,
        path: params.path,
        mapTokens: params.map_tokens,
        signal,
        execute: (command, args, options) => pi.exec(command, args, options),
      });

      const output = result.output || "(Aider produced an empty repository map.)";
      const truncation = truncateHead(output, {
        maxLines: DEFAULT_MAX_LINES,
        maxBytes: DEFAULT_MAX_BYTES,
      });
      const cachePath = join(result.repositoryPath, ".aider.tags.cache.v4");
      const details: RepoMapDetails = {
        repositoryPath: result.repositoryPath,
        mapTokens: result.mapTokens,
        cachePath,
        cacheExists: await pathExists(cachePath),
      };
      let text = truncation.content;

      if (truncation.truncated) {
        const outputDirectory = await mkdtemp(join(tmpdir(), "pi-repo-map-"));
        const fullOutputPath = join(outputDirectory, "repo-map.txt");
        await withFileMutationQueue(fullOutputPath, async () => {
          await writeFile(fullOutputPath, output, "utf8");
        });
        details.fullOutputPath = fullOutputPath;
        text += `\n\n[Output truncated: showing ${truncation.outputLines} of ${truncation.totalLines} lines `;
        text += `(${formatSize(truncation.outputBytes)} of ${formatSize(truncation.totalBytes)}). `;
        text += `Full output saved to: ${fullOutputPath}]`;
      }

      return {
        content: [{ type: "text", text }],
        details,
      };
    },
  });
}
