#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

missing_dependency() {
  local command_name="$1"
  echo "Missing dependency: $command_name" >&2
  if [ "$command_name" = "aider" ]; then
    cat >&2 <<'INSTRUCTIONS'
Install the validated Aider version with uv:
  uv python install 3.12
  uv tool install --force --python python3.12 --with pip 'aider-chat==0.86.2'
INSTRUCTIONS
  fi
  exit 1
}

for command_name in pi git aider; do
  command -v "$command_name" >/dev/null 2>&1 || missing_dependency "$command_name"
done

if ! aider --help 2>&1 | grep -q -- "--show-repo-map"; then
  echo "Installed aider does not support --show-repo-map." >&2
  echo "Install the validated version: aider-chat==0.86.2" >&2
  exit 1
fi

pi install "$PACKAGE_DIR"

echo "Installed pi-repo-map-extension from: $PACKAGE_DIR"
echo "Keep this directory in place: Pi references local packages instead of copying them."
echo "Start a fresh Pi session in a Git repository and ask Pi to call repo_map."
